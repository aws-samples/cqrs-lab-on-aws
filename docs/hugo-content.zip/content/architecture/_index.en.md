+++
title = "	Architecture"
date = 2019-03-05
weight = 11
+++

As depicted in the diagram below, this demo app is implemented in the AWS cloud native way, couples of Lambda functions for serving APIs behinds API gateway, and use DynamoDB and RDS MySQL as data store and Kinesis Stream as temp stream storage, it is serverless style architecture except the RDS MySQL part, mainly it consists of 4 groups:

![Architecture Diagram](architecture/architecture.png)

## Components

As illustrated in above architecture, this demo app mainly consists of below parts:

#### Command Service
This handles various of ticket booking related command http request and persist command information into DDB. This is the implementation for the customer user story part.

#### Change Data Capture Service
This captures the data change from DDB table, then do necessary data transformation, and finally flush the data delta into RDS MySQL DB tables

#### Query Service
This component provides various of query API for serving the air ticket admin user stories

#### Data Ingestor

This is a Python script locates in `src/ingestor.py` which encapsulate the above Command/Query API, it provides a series of operation numbers for simulating user story APIs as well as some system maintainence/query APIs, which makes the lab experiment much more convinient for users.