+++
title = "Deploy CQRS Stack"
date = 2019-10-30T17:50:15-07:00
weight = 15
+++

To simply the demo app deployment, we leverage AWS CDK (Cloud Development Kit, https://aws.amazon.com/cdk/) which provides developer bootstrapping aws cloud infrastructure by writting structured code instead of CloudFormation YAML files, follow below steps getting every components in AWS cloud setup:

Clone source code and  run:
```bash
 git clone https://github.com/aws-samples/cqrs-lab-on-aws
 cd cqrs/src/
 sudo /usr/local/bin/pip3 install -r requirements.txt
 npm install -g aws-cdk
 cdk bootstrap
```

Verify cloudformation stack CDKToolkit has been created for managing CDK meta data like below:

![CDKToolkit](module1/cdktoolkit.png)

Log on AWS management console, choose region: us-east-1，select service: system manager parameter store, create secure string with parameter name: AirTicket.AdminPass, Value: password, leave the KMS key source and id as default

Use CDK to deploy the CQRS Stack:

```bash
lambda/install_pymysql.sh
cdk deploy
```

Input `y` for question: `Do you wish to deploy these changes (y/n)?`

Wait for about 10 minutes and then verify the cloufromation stack "cqrs" has been deployed as below:
![CQRS Stack](module1/stack.png)

Now you can check out the provisioned components and resources described architecture diagram.
