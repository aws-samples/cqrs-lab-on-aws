+++
title = "User Stories"
date = 2019-03-06
weight = 8
+++

From the product requirement analysis perspective, as this is a demo app for  airline ticket booking, as below depicts it mainly consists use cases for passenger and administrator respectively, which corresponds to Command and Query part in the CQRS pattern.

### Flight Passenger Customer Perspective Stories (Command Part)

- As a Passengercustomer, I could put an order with "customer id, flight id, date time" for reserving flight.
- As a customer, I could update my flight order
- As a customer, I could cancel my flight order
- As a customer, I could list all my orders and check out details

### Flight Admin Perspective Stories (Query Part)

- As a admin, I could query customer flight booking information so that I could dispatch notification to them when I cancel or update flight information
- As a admin, I could query customers with flights start/transfer/stop contains city with extreme whether  so that I could send out reminder msg.