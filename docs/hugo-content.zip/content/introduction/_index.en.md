+++
title = "Introduction"
weight = 5
+++

This lab is a air ticketing booking demo app for illustrating CQRS(Command Query Responsibility Seggregation, see more on https://www.martinfowler.com/bliki/CQRS.html) architecture pattern, the goal of this sample app is to demonstrate CQRS architecture concept and its reference architecture, design and implementation based on AWS services, which include:

- IAM
- API Gateway
- Lambda
- DynamoDB
- RDS MySQL
- Kinesis Stream
- CDK (Cloud Development Kit)

Those services will compose below architecture (See Architecture section for details):
![Architecture Diagram](architecture/architecture.png)

By completing this lab, it will help attendees to understand how to use AWS cloud native way to implement CQRS pattern, and its challenge and corresponding solutions.