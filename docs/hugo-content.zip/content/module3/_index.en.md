+++
title = "Clean Up"
date = 2019-10-30T17:50:15-07:00
weight = 20
+++


To clean up and avoid unnessary cost, use CDK to delete the CQRS Stack:

```bash
cdk destroy
```

Input `y` for prompt question, then wait for about 10 minutes and verify the cloufromation stack "cqrs" has been deleted.