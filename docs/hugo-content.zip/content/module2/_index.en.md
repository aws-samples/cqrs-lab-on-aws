+++
title = "Demo Steps"
date = 2020-03-05
weight = 20

+++

To demonstrate the above user stories and do necessary system checks, we take advantage of the ingestor script, which encapsulate various of HTTP API calls to the Command and Query endpoints provisioned in setup step. In each section, you could log on AWS management console to check out the data flows depicted in the architecture diagram.

#### Initialize DB 

Now let's start ingestor script:
```bash
python3 ingestor.py
```

Input `1` to initialize RDS MySQL DB
![Init DB](module2/init.png)


#### Customer Initialization  

Input 6，which will insert 20 customers into DDB, verify the records in DDB CQRS table

![Create Customer](module2/ddb.png)

Then input 3, which will invoke the lambda and it will read customer info from RDS MySQL users table, it will show `Total customer number is 20`

![Create Customer](module2/customer.png)

#### Air Ticket Order Workflow

Input 7，it will show many orders placed, verify the orders are updated into DDB CQRS table customers records


Input 4, then MU5159, the script return `Customer number is 8` , which verifies there are 8 customers who have order flight MU5159

Input 8, the script will randomly cancel some orders, then input 4 and MU5159, then it returns `Customer number is 4`, which verify some orders were successfully cancelled

#### Error Handling Workflow

Check out the msg in Queue: cqrs-DeadLetterQueuexxx

Input 11, which will input some malformed data which leads to error, verify that the dead letter msg queu number increased by 1

#### Duplication Msg Handling

Input 2 via ingestor script, this will empty the DDB CQRS table and clear the RDS MySQL table records, input 3 to verify that 0 is returned, which means all table are empty now

Input 10, then input 3, it returns `Total customer number is 1`, which means only 1 customer now

