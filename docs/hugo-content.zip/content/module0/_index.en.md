+++
title = "Preparation"
date = 2019-03-05
weight = 12
+++

To simply the lab environment setup and eliminate the OS differences among Mac/Win/Linux systems, we leverage AWS Cloud9 service for setting up our demo app, which basically provides web IDE for Linux development box.

#### Setup Cloud9 Environment

Create an cloud9 env based on OS **Aamazon Linux 2** 

Disable Cloud9 temp credentials by: Cloud9 ide > aws settings > credentials > aws managed temp credentials, and disable it like below:

![Cloud9 IDE](module0/cloud9.png)


Remove the line with "token" in file `~/.aws/credentials` to force aws CLI use AK/SK instead of the empty token

Run `aws configure` to config your AWS CLI env with administrative user AK/SK and default region, recommend using 'us-east-1' for latest lambda feature and all the AWS services/resource required

Run `aws sts get-caller-identity` to check out the return, should be similar to below output:

```bash
{
    "UserId": "AROARZ6RU6WVQQ4367OXX:i-031daf81927895e1d",
    "Account": "124456859xxxx",
    "Arn": "arn:aws:sts::12445685xxxx:assumed-role/xxxxx/i-031daf81927895e1d"
}
```

#### Config Python Environment

Update pip to pip3. On amazon linux 2, python 2.7 is the default python version, pip version is 9, run below commands to check out python and pip version, make sure they are on python3.6/pip3 19:

```bash
wget https://bootstrap.pypa.io/get-pip.py
sudo python3 get-pip.py
pip -V
python -V
```




